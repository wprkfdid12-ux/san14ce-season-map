def sig(p):
    return {}

def rdef(p):
    return [], []
